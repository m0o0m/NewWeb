﻿using GL.Common;
using log4net;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GL.Pay.Apple.ReceiptVerifier;
using GL.Data.Model;
using GL.Data.BLL;
using ProtoCmd.BackRecharge;
using GL.Protocol;
using Web.Pay.protobuf.SCmd;
using System.Text;
using GL.Pay.AliPay;

namespace Web.Pay.Controllers
{
    public class SignController : Controller
    {
        private const string _key = "515IWOXXXeYiw89y";
        private ILog log = LogManager.GetLogger("Sign");
        // GET: Sign
        [QueryValues]
        //[HttpPost]
        public ActionResult AppStore(Dictionary<string, string> queryvalues)
        {

//#if Debug
//            queryvalues = new Dictionary<string, string>();
//            queryvalues.Add("transtime", "1450150559");
//            queryvalues.Add("productid", "5b_7");
//            queryvalues.Add("identityid", "22254");
//            queryvalues.Add("othertype", "2");
//            queryvalues.Add("other", "1E1289A4-4DE7-433C-BD47-70392CC10EE0");
//            queryvalues.Add("customsign", "a096657051264106f74df29bd2f6b07d");

//            queryvalues.Add("transactionid", "1000000185044074");
//            queryvalues.Add("isfirstrecharge", "0");
//            queryvalues.Add("transactionreceipt", "ewoJInNpZ25hdHVyZSIgPSAiQW9FcGZoWGE5RnVtMXNBSFhSdnVkbnJwWjZwaXZaMFdFbFEzNzlLQkE1eUwwcnNKODg1VERpbklIaDg1V0dqQVY0d2VRL3B4UXpONnFwQ1BSSXN3THpNaWJrMnFZek1xQ3BJRENzcERCZ2U4Rk80bW5XNUhENzUyZmlhaGRySTA4VGVXNXlQRHlwK3l0SzBPb1FpWmMrdDBPTUFYbVFYcEFQYjlvK2dhNUJyTkFBQURWekNDQTFNd2dnSTdvQU1DQVFJQ0NCdXA0K1BBaG0vTE1BMEdDU3FHU0liM0RRRUJCUVVBTUg4eEN6QUpCZ05WQkFZVEFsVlRNUk13RVFZRFZRUUtEQXBCY0hCc1pTQkpibU11TVNZd0pBWURWUVFMREIxQmNIQnNaU0JEWlhKMGFXWnBZMkYwYVc5dUlFRjFkR2h2Y21sMGVURXpNREVHQTFVRUF3d3FRWEJ3YkdVZ2FWUjFibVZ6SUZOMGIzSmxJRU5sY25ScFptbGpZWFJwYjI0Z1FYVjBhRzl5YVhSNU1CNFhEVEUwTURZd056QXdNREl5TVZvWERURTJNRFV4T0RFNE16RXpNRm93WkRFak1DRUdBMVVFQXd3YVVIVnlZMmhoYzJWU1pXTmxhWEIwUTJWeWRHbG1hV05oZEdVeEd6QVpCZ05WQkFzTUVrRndjR3hsSUdsVWRXNWxjeUJUZEc5eVpURVRNQkVHQTFVRUNnd0tRWEJ3YkdVZ1NXNWpMakVMTUFrR0ExVUVCaE1DVlZNd2daOHdEUVlKS29aSWh2Y05BUUVCQlFBRGdZMEFNSUdKQW9HQkFNbVRFdUxnamltTHdSSnh5MW9FZjBlc1VORFZFSWU2d0Rzbm5hbDE0aE5CdDF2MTk1WDZuOTNZTzdnaTNvclBTdXg5RDU1NFNrTXArU2F5Zzg0bFRjMzYyVXRtWUxwV25iMzRucXlHeDlLQlZUeTVPR1Y0bGpFMU93QytvVG5STStRTFJDbWVOeE1iUFpoUzQ3VCtlWnRERWhWQjl1c2szK0pNMkNvZ2Z3bzdBZ01CQUFHamNqQndNQjBHQTFVZERnUVdCQlNKYUVlTnVxOURmNlpmTjY4RmUrSTJ1MjJzc0RBTUJnTlZIUk1CQWY4RUFqQUFNQjhHQTFVZEl3UVlNQmFBRkRZZDZPS2RndElCR0xVeWF3N1hRd3VSV0VNNk1BNEdBMVVkRHdFQi93UUVBd0lIZ0RBUUJnb3Foa2lHOTJOa0JnVUJCQUlGQURBTkJna3Foa2lHOXcwQkFRVUZBQU9DQVFFQWVhSlYyVTUxcnhmY3FBQWU1QzIvZkVXOEtVbDRpTzRsTXV0YTdONlh6UDFwWkl6MU5ra0N0SUl3ZXlOajVVUllISytIalJLU1U5UkxndU5sMG5rZnhxT2JpTWNrd1J1ZEtTcTY5Tkluclp5Q0Q2NlI0Szc3bmI5bE1UQUJTU1lsc0t0OG9OdGxoZ1IvMWtqU1NSUWNIa3RzRGNTaVFHS01ka1NscDRBeVhmN3ZuSFBCZTR5Q3dZVjJQcFNOMDRrYm9pSjNwQmx4c0d3Vi9abEwyNk0ydWVZSEtZQ3VYaGRxRnd4VmdtNTJoM29lSk9PdC92WTRFY1FxN2VxSG02bTAzWjliN1BSellNMktHWEhEbU9Nazd2RHBlTVZsTERQU0dZejErVTNzRHhKemViU3BiYUptVDdpbXpVS2ZnZ0VZN3h4ZjRjemZIMHlqNXdOelNHVE92UT09IjsKCSJwdXJjaGFzZS1pbmZvIiA9ICJld29KSW05eWFXZHBibUZzTFhCMWNtTm9ZWE5sTFdSaGRHVXRjSE4wSWlBOUlDSXlNREUxTFRFeUxURTBJREU1T2pNMU9qVTJJRUZ0WlhKcFkyRXZURzl6WDBGdVoyVnNaWE1pT3dvSkluVnVhWEYxWlMxcFpHVnVkR2xtYVdWeUlpQTlJQ0ptWWpBMVlqbGpObVUzTm1VNVl6WmtOamc1TWpsaVlqTTNZMkZsWmpkaVpHUmhPRFZsTmpaaUlqc0tDU0p2Y21sbmFXNWhiQzEwY21GdWMyRmpkR2x2YmkxcFpDSWdQU0FpTVRBd01EQXdNREU0TlRBME5EQTNOQ0k3Q2draVluWnljeUlnUFNBaU1TSTdDZ2tpZEhKaGJuTmhZM1JwYjI0dGFXUWlJRDBnSWpFd01EQXdNREF4T0RVd05EUXdOelFpT3dvSkluRjFZVzUwYVhSNUlpQTlJQ0l4SWpzS0NTSnZjbWxuYVc1aGJDMXdkWEpqYUdGelpTMWtZWFJsTFcxeklpQTlJQ0l4TkRVd01UVXdOVFUyTnpBNUlqc0tDU0oxYm1seGRXVXRkbVZ1Wkc5eUxXbGtaVzUwYVdacFpYSWlJRDBnSWpjMlJVSXdNakJGTFRjNE1ETXRORFU0TVMxQ1JVWTNMVVV6UlRaRVFqUTBSak15TUNJN0Nna2ljSEp2WkhWamRDMXBaQ0lnUFNBaU5XSmZNU0k3Q2draWFYUmxiUzFwWkNJZ1BTQWlNVEEyTmpFd09ESTFPQ0k3Q2draVltbGtJaUE5SUNKamIyMHVaMkZ0WlRVeE5TNDFNVFZrWlhwb2IzVWlPd29KSW5CMWNtTm9ZWE5sTFdSaGRHVXRiWE1pSUQwZ0lqRTBOVEF4TlRBMU5UWTNNRGtpT3dvSkluQjFjbU5vWVhObExXUmhkR1VpSUQwZ0lqSXdNVFV0TVRJdE1UVWdNRE02TXpVNk5UWWdSWFJqTDBkTlZDSTdDZ2tpY0hWeVkyaGhjMlV0WkdGMFpTMXdjM1FpSUQwZ0lqSXdNVFV0TVRJdE1UUWdNVGs2TXpVNk5UWWdRVzFsY21sallTOU1iM05mUVc1blpXeGxjeUk3Q2draWIzSnBaMmx1WVd3dGNIVnlZMmhoYzJVdFpHRjBaU0lnUFNBaU1qQXhOUzB4TWkweE5TQXdNem96TlRvMU5pQkZkR012UjAxVUlqc0tmUT09IjsKCSJlbnZpcm9ubWVudCIgPSAiU2FuZGJveCI7CgkicG9kIiA9ICIxMDAiOwoJInNpZ25pbmctc3RhdHVzIiA9ICIwIjsKfQ==");
//#endif



            string _transtime = queryvalues.ContainsKey("transtime") ? queryvalues["transtime"] : string.Empty;
            string _productid = queryvalues.ContainsKey("productid") ? queryvalues["productid"] : string.Empty;
            int _identityid = queryvalues.ContainsKey("identityid") ? Convert.ToInt32(queryvalues["identityid"]) : 0;
            int _othertype = queryvalues.ContainsKey("othertype") ? Convert.ToInt32(queryvalues["othertype"]) : 0;
            string _other = queryvalues.ContainsKey("other") ? queryvalues["other"] : string.Empty;
            string _customSign = queryvalues.ContainsKey("customsign") ? queryvalues["customsign"] : string.Empty;

            string Key = _key;

            string _transactionid = queryvalues.ContainsKey("transactionid") ? queryvalues["transactionid"] : string.Empty;
            int _isfirstrecharge = queryvalues.ContainsKey("isfirstrecharge") ? Convert.ToInt32(queryvalues["isfirstrecharge"]) : 0;
            string _transactionreceipt = queryvalues.ContainsKey("transactionreceipt") ? queryvalues["transactionreceipt"] : string.Empty;
            string md5 = Utils.MD5(string.Concat(_transtime, _identityid, _othertype, _other, _productid, Key));

            if (!_customSign.Equals(md5))
            {
                log.Error("AppStore 参数不正确");
                return Json(new { result = 10001, msg = "AppStore 参数不正确" });
            }


            //Convert.FromBase64String(System.Text.Encoding.ASCII.GetBytes(_transactionreceipt))
            var res = System.Text.Encoding.ASCII.GetString(Convert.FromBase64String(_transactionreceipt));

            //(JObject)JsonConvert.DeserializeObject


            ReceiptManager receiptManager = new ReceiptManager();
            var env = Environments.Production;
            if (res.IndexOf("Sandbox") > 0)
            {
                env = Environments.Sandbox;
            }
            var response = receiptManager.ValidateReceipt(env, res);


            if (response.Status > 0)
            {
                log.Error("AppStore ReceiptVerifier Error Status :"+ response.Status);
                return Json(new { result = response.Status });
            }


            if (!(response.Receipt.BundleIdentifier == "com.game515.wywdezhou" || response.Receipt.BundleIdentifier == "com.game515.515dezhou"))
            {
                log.Error("AppStore ReceiptVerifier Error bid :" + response.Receipt.BundleIdentifier);
                return Json(new { result = 10006, msg = "AppStore ReceiptVerifier Error bid :" + response.Receipt.BundleIdentifier });
            }


            try
            {


                //RechargeCheck rc = RechargeCheckBLL.GetModelBySerialNo(new RechargeCheck { SerialNo = out_trade_no });

                //if (rc == null)
                //{
                //    log.Error(" AppStore 订单[" + out_trade_no + "]不存在");
                //    return Content("fail");
                //}
                Recharge rc = RechargeBLL.GetModelByBillNo(new Recharge { BillNo = _transactionid });
                if (rc != null)
                {
                    log.Error(" AppStore 订单[" + _transactionid + "]已存在");
                    return Json(new { result = 1, msg = "AppStore 订单[" + _transactionid + "]已存在" });
                }


                Role user = RoleBLL.GetModelByID(new Role { ID = _identityid });
                if (user == null)
                {

                    log.Error(" AppStore 用户[" + _identityid + "]不存在");
                    return Json(new { result = 10002, msg = "AppStore 用户[" + _identityid + "]不存在" });
                }
                IAPProduct iap = IAPProductBLL.GetModelByID(_productid);
                if (iap == null)
                {
                    log.Error(" AppStore 支付配表出错");
                    return Json(new { result = 10003, msg = "AppStore 支付配表出错" });
                }


                isFirst iF = iap.product_id.Split('_')[0].Equals("firstCharge") ? isFirst.是 : isFirst.否;
                chipType ct = iF == isFirst.是 ? chipType.首冲礼包 : (chipType)iap.goodsType;

              

                bool firstGif = iF == isFirst.是;


             
                Recharge recharge = RechargeBLL.GetFirstModelListByUserID(new Recharge { UserID = _identityid });
                if (recharge != null)//首冲过
                {
                    if (firstGif == true)
                    {//又是首冲，则改变其为不首冲
                        firstGif = false;
                        ct = (chipType)1;
                        iF = isFirst.否;
                        iap.goodsType = 1;
                        log.Error(" 多次首冲，修改firstGif值");
                    }
                }

                RechargeCheckBLL.AddOrderIP(new UserIpInfo { UserID = _identityid, OrderID = _transactionid, CreateTime = DateTime.Now, ChargeType = (int)raType.AppStore, OrderIP = GetClientIp() });
                RechargeIP ipmodel = GetCallBackClientIp();
                RechargeCheckBLL.AddCallBackOrderIP(new UserIpInfo { CallBackUserID = _identityid, OrderID = _transactionid, Method = ipmodel.Method, CallBackIP = ipmodel.IP, CallBackTime = DateTime.Now, CallBackChargeType = (int)raType.AppStore });





                uint gold = iap.goodsType == 1 ? (uint)iap.goods : 0;
                uint dia = iap.goodsType == 2 ? (uint)iap.goods : 0;
                if (firstGif)
                {
                    gold = (uint)(iap.goods + iap.attach_chip);
                    dia = (uint)iap.attach_5b;
                }

                uint rmb = (uint)iap.price;
                log.Info(" 分 :"+ rmb * 100);
                // rmb = rmb * 100;//将元单位转换为分的单位转给游戏服务器
                normal ServiceNormalS = normal.CreateBuilder()
                .SetUserID((uint)_identityid)
                .SetGold(gold)
                .SetDia(dia)
                .SetRmb(rmb*100)//将元单位转换为分的单位转给游戏服务器
                .SetFirstGif(firstGif)
                .SetBillNo(_transactionid)
                .Build();

                Bind tbind = Cmd.runClient(new Bind(BR_Cmd.BR_NORMAL, ServiceNormalS.ToByteArray()));
                switch ((CenterCmd)tbind.header.CommandID)
                {
                    case CenterCmd.CS_NORMAL:
                        normalRep ServiceNormalC = normalRep.ParseFrom(tbind.body.ToBytes());
                        log.Info(" AppStore ServiceResult : " + ServiceNormalC.Suc);
                        if (ServiceNormalC.Suc)
                        {
                            log.Info(" AppStore ServiceResult [" + _transactionid + "] : " + ServiceNormalC.Suc);
                            //RechargeCheckBLL.Delete(new RechargeCheck { SerialNo = rc.SerialNo });
                        }
                        //Response.Redirect("mobilecall://fail?suc=" + ServiceNormalC.Suc);
                        break;
                    case CenterCmd.CS_CONNECT_ERROR:
                        break;
                }


                log.Info(" AppStore Process Success[" + _transactionid + "]: " + Utils.GetUrl() + "?" + Core.CreateLinkStringUrlencode(queryvalues, Encoding.UTF8));
                RechargeBLL.Add(new Recharge { BillNo = _transactionid, OpenID = response.Receipt.UniqueIdentifier, UserID = _identityid, Money = (rmb * 100), CreateTime = DateTime.Now, Chip = gold, Diamond = dia, ChipType = ct, IsFirst = iF, NickName = iap.productname, PayItem = iap.product_id, PF = raType.AppStore, UserAccount = user.NickName });
                return Json(new
                {
                    result = 0,
                    productid = _productid,
                    transactionid = _transactionid,
                    isfirstrecharge = _isfirstrecharge
                });


                //log.Error(" AppStore fail : q " + Utils.GetUrl() + Utils.CreateLinkStringUrlencode(queryvalues, Encoding.UTF8));
                //return Json(new { result = 10004, msg = "AppStore 服务器发货失败" });
            }
            catch (Exception err)
            {
                log.Error(" AppStore fail : q " + Utils.GetUrl() + Utils.CreateLinkStringUrlencode(queryvalues, Encoding.UTF8), err);
                return Json(new { result = 10005, msg = "AppStore 服务器发货失败 err:" + err.Message });
            }
        }


        private string GetClientIp()
        {
            try
            {

                string userIP = System.Web.HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
                if (string.IsNullOrEmpty(userIP))
                {
                    userIP = System.Web.HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                }
                if (string.IsNullOrEmpty(userIP))
                {
                    userIP = System.Web.HttpContext.Current.Request.UserHostAddress;
                }
                return userIP;
            }
            catch {
                return "0.0.0.0";
            }
          

        }

        private RechargeIP GetCallBackClientIp()
        {
            RechargeIP mode = new RechargeIP();
            string userIP = System.Web.HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (string.IsNullOrEmpty(userIP))
            {
                userIP = System.Web.HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                mode.Method = "REMOTE_ADDR";
            }
            else
            {
                mode.Method = "HTTP_X_FORWARDED_FOR";
            }
            mode.IP = userIP;
            return mode;

        }

    }
}