﻿using GL.Common;
using GL.Data.BLL;
using GL.Data.Model;
using GL.Pay.AliPay;
using GL.Pay.QQPay;
using GL.Pay.WxPay;
using GL.Pay.YeePay;
using GL.Protocol;
using log4net;
using ProtoCmd.BackRecharge;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using Web.Pay.JsonMapper;
using Web.Pay.Models;
using Web.Pay.protobuf.SCmd;
using System.Collections;
using GL.Pay.Baidu;
using Newtonsoft.Json;
using GL.Pay.Unicom;
using GL.Pay.XY;
using GL.Pay.Hippocampi;
using System.Net;
using System.Xml.Serialization;
using System.IO;
using System.Xml.Linq;
using System.Data;
using GL.Pay.ZY;
using GL.Pay.YYH;
using System.Web.Script.Serialization;
using GL.Pay.MeiZu;
using System.Threading;

namespace Web.Pay.Controllers
{
    public class PayMoney
    {
        public  string PayTest(int UserID, uint gold, uint dia,uint rmb,bool firstGif,string billNO, int iF2, int myType) {
#if Test
           isFirst iF = (isFirst)iF2;

            normal ServiceNormalS = normal.CreateBuilder()
             .SetUserID((uint)UserID)
             .SetGold(gold)
             .SetDia(dia)
             .SetRmb(rmb)//单位 分
             .SetFirstGif(firstGif)
             .SetBillNo(billNO)
             .Build();

            Bind tbind = Cmd.runClient(new Bind(BR_Cmd.BR_NORMAL, ServiceNormalS.ToByteArray()));
            switch ((CenterCmd)tbind.header.CommandID)
            {
                case CenterCmd.CS_NORMAL:
                    normalRep ServiceNormalC = normalRep.ParseFrom(tbind.body.ToBytes());
                   
                    if (ServiceNormalC.Suc)
                    {
                       
                    }
                    //Response.Redirect("mobilecall://fail?suc=" + ServiceNormalC.Suc);
                    break;
                case CenterCmd.CS_CONNECT_ERROR:
                    return "";
                   
            }
            RechargeBLL.Add(
                      new Recharge
                      {
                          BillNo = billNO,
                          OpenID = billNO,
                          UserID = UserID,
                          Money = (long)rmb,
                          CreateTime = DateTime.Now,
                          Chip = gold,
                          Diamond = dia,
                          ChipType = (chipType)myType,
                          IsFirst = iF,
                          PF = raType.微信,
                          PayItem = "Chip_8"


                      });
            RechargeCheckBLL.Delete(new RechargeCheck { SerialNo = billNO });
#endif

            return "1";


        
        }
    }
}