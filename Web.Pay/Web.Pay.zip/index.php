<?php

echo "Hello World!";

?>